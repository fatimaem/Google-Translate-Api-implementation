﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace carcrud.Models
{
    public class CarDbModel
    {
        [Required]
        public string Name { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        [Range(1000,double.MaxValue)]
        public double Price { get; set; }

        public int Id { get; set; }
    }
}
