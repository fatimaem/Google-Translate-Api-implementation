﻿using carcrud.Models;
using Microsoft.EntityFrameworkCore;

namespace ContosoUniversity.Data
{
    public class CarsDbContext : DbContext
    {
        public CarsDbContext(DbContextOptions<CarsDbContext> options) : base(options)
        {

        }

        public virtual  DbSet<CarDbModel> cars { get; set; }

      
      
    }
}
